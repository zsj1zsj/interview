from flask import Flask, render_template, request, jsonify, session,abort
import pandas as pd
import csv
from prodplan import *
from validation import *
import uuid

app = Flask(__name__)

@app.route('/upload', endpoint='index')
def upload_file():
   return render_template('upload.html')
	
@app.route('/uploader', methods = ['GET', 'POST'], endpoint='upload')
def upload_file():
   if request.method == 'POST':
      f = request.files['file']
      predbuilddays = request.form.get('predbuilddays')
      print(f'upload.predbuilddays:{predbuilddays}')
      prodplan = ProdPlan()
      df=pd.read_csv(request.files.get('file'))
      valid = Validation()
      if not valid.csvcolintact(df):
        abort(422, 'column not intact')
      if not valid.csvdataintact(df):
        abort(422, 'data not correct')
      err = valid.validpersiteprod(df)
      if  err!='':
        abort(422, err)
      #print(df)
      prodforecast = prodplan.forecastall(df,int(predbuilddays))
      #f.save(f"uploadfiles/{f.filename}")
      rndfilename=f"{uuid.uuid4().hex}.csv"
      prodforecast.to_csv(f"static/files/{rndfilename}",index=False)
      #abort(422,{'custom error message to appear in body'})
      return jsonify(HTMLTab=prodforecast.to_html(index=False),downloadfile = rndfilename)
      #return render_template('table_overview.html', title='Overview', tables=[df.to_html()])

@app.errorhandler(422)
def page_not_found(error):
    print(error.description)
    print(f'error:{str(error)}')
    #response = jsonify({'message': error.get_description()['message']})
    return jsonify(message=str(error)), 422

		
if __name__ == '__main__':
   app.run(debug = True)
