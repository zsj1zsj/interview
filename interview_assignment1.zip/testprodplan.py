import unittest
from prodplan import *

#CONF_LOG = "./config/config.ini"
#logging.config.fileConfig(CONF_LOG);

class TestProdPlan(unittest.TestCase):        
    #def validpersiteprod(self,prodplan):
    
    #pre-build days =7, compare result with output4.csv
    def test_forecastall1(self):
        prodplan = ProdPlan()
        df = pd.read_csv('testcases/input4.csv')
        res = prodplan.forecastall(df)
        pred = list(res['produce'])
        
        acutl = list(pd.read_csv('testcases/output4.csv')['produce'])
        self.assertListEqual(pred,acutl)
    
    #pre-build days =10, compare result with output5.csv
    def test_forecastall2(self):
        prodplan = ProdPlan()
        df = pd.read_csv('testcases/input5.csv')
        res = prodplan.forecastall(df,predbuilddays=10)
        pred = list(res['produce'])
        acutl = list(pd.read_csv('testcases/output5.csv')['produce'])
        self.assertListEqual(pred,acutl)
    
if __name__ == '__main__':
    unittest.main(verbosity=2)
