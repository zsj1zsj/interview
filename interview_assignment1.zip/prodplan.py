import numpy as np
import pandas as pd
import logging
import logging.config
import os

CONF_LOG = "./config/config.ini"
#logging.config.fileConfig(CONF_LOG);

class ProdPlan:
    def forecastpersiteprod(self,produce,predbuilddays=7):
        print(f'forecastpersiteprod.predbuilddays:{predbuilddays}')
        indecies =[0]
        for i in range(len(produce)):
            if produce[i]!=0:
                indecies.append(i)
        #logging.debug(indecies)

        count =0
        produce[0]=0
        for i in range(1,len(indecies)):
            start = -1 if indecies[i-1]==0 else indecies[i-1]
            diff = indecies[i]-start
            if diff>predbuilddays:
                realbuild = diff - predbuilddays
                logging.debug("start:{} diff:{} realbuild:{}".format(start,diff,realbuild))
                produce[start+1:start+1+realbuild]=produce[start]
                produce[start+1+realbuild:indecies[i]]=np.linspace(produce[indecies[i-1]],produce[indecies[i]],predbuilddays+1)[1:-1].astype(np.int32)
            else:
                logging.debug("start:{} diff:{}".format(start,diff))
                produce[start+1:indecies[i]]=np.linspace(produce[indecies[i-1]],produce[indecies[i]],diff+1)[1:-1].astype(np.int32)
        return produce
            
        
    def forecastall(self,prodcastcvs,predbuilddays=7):
        print(f'forecastall.predbuilddays:{predbuilddays}')
        #logging.debug(prodcastcvs)
        grouped = prodcastcvs.groupby(['site','product'])
        res = pd.DataFrame()
        for _, group in grouped:
            produce = self.forecastpersiteprod(group['demand'].fillna(0).to_numpy(),predbuilddays=predbuilddays)
            group = group.fillna(method='ffill')
            group=group.fillna(0)
            group['produce'] = produce
            #logging.debug(group)
            res= res.append(group,ignore_index=True)
        res = res.astype({"produce": int})
        return res
        
    def validatefileformat():
        pass

#prodplan = ProdPlan()
#filename = "D:/interview/input.csv"
#prodcastcvs = pd.read_csv(filename, sep=',')
#print(prodplan.forecastall(prodcastcvs))
