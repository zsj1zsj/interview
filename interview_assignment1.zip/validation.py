import pandas
import json
import configparser
import logging
import pandas as pd


class Validation:
    def __init__(self):
        self.config = configparser.ConfigParser()
        self.config.read("config.ini")
        logging.info("config.ini loaded")
        self.CSV_COLUMNS = json.loads(self.config['DEFAULT']['columns'])
        
    def iscvsfile():
        pass

    def csvcolintact(self,df : pandas.core.frame.DataFrame)->bool:
        columns = list(df.columns)
        if len(columns)!=len(self.CSV_COLUMNS):
            return False
        for column in self.CSV_COLUMNS:
            if column not in columns:
                return False
        return True
    
    def csvdataintact(self, df : pandas.core.frame.DataFrame)->bool:
        for column in self.CSV_COLUMNS:
            if self.config.has_option('DEFAULT', column):
                if not df[column].dtype.name.startswith(self.config['DEFAULT'][column]):
                    return False
        return True
    
    def validpersiteprod(self, df : pandas.core.frame.DataFrame)->bool:
        grouped = df.groupby(['site','product'])
        res = pd.DataFrame()
        for _, group in grouped:
            olddemand=0
            days = set()
            err = ""
            for index,row in group.iterrows():
                #over supply
                if row['demand']<olddemand:
                    err= 'demand quantity not correct'
                    logging.error(err)
                    return err
                if row['day'] in days:
                    err= 'duplicated days in csv file.'
                    return err
                else:
                    days.add(row['day'])
        return err
        

#df = pd.read_csv('testcases/input3.csv')        
#print(df.dtypes)
