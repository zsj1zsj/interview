import unittest
import pandas as pd
from validation import *

class TestValidation(unittest.TestCase):
    #missing column in the csv file
    def test_csvcolintact1(self):
        valid = Validation()
        df = pd.read_csv('testcases/input1.csv')
        self.assertFalse(valid.csvcolintact(df))
    
    #no issue
    def test_csvcolintact2(self):
        valid = Validation()
        df = pd.read_csv('testcases/input2.csv')
        self.assertTrue(valid.csvcolintact(df))
        
    #data type not correct
    def test_csvdataintact1(self):
        valid = Validation()
        df = pd.read_csv('testcases/input3.csv')
        self.assertFalse(valid.csvdataintact(df))
        
    #data type is correct
    def test_csvdataintact2(self):
        valid = Validation()
        df = pd.read_csv('testcases/input2.csv')
        self.assertTrue(valid.csvdataintact(df))
        
        
    def test_validpersiteprod(self):
        valid = Validation()
        df = pd.read_csv('testcases/input2.csv')
        self.assertFalse(valid.validpersiteprod(df))
        
if __name__ == '__main__':
    unittest.main(verbosity=2)