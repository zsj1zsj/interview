Steps to run the project:
1. To start flask app, run command "python upload.py"

2. open url: ' localhost:5000/upload' in browser




Structure for the proejct:
\INTERVIEW
├─screenshots               			  screenshots for 
├─static                         			  css, js files
│  └─files
├─templates                 			  html templates
├─testcases                  			  unit test testcases
├─prodplan.py, validation.py,upload.py                   python source
└─test*.py                                                                    unit test code
