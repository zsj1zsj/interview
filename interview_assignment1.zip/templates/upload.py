from flask import Flask, render_template, request
import pandas as pd
app = Flask(__name__)

@app.route('/upload', endpoint='index')
def upload_file():
   return render_template('upload.html')
	
@app.route('/uploader', methods = ['GET', 'POST'], endpoint='upload')
def upload_file():
   if request.method == 'POST':
      f = request.files['file']
      
      content = f.readlines()
      #f.save(f.filename)
      ipl_data = {'Team': ['Riders', 'Riders', 'Devils', 'Devils', 'Kings',
         'kings', 'Kings', 'Kings', 'Riders', 'Royals', 'Royals', 'Riders'],
         'Rank': [1, 2, 2, 3, 3,4 ,1 ,1,2 , 4,1,2],
         'Year': [2014,2015,2014,2015,2014,2015,2016,2017,2016,2014,2015,2017],
         'Points':[876,789,863,673,741,812,756,788,694,701,804,690]}
      df = pd.DataFrame(ipl_data)
      #print(df)
      #return 'file uploaded successfully'
      print('changed')
      return render_template('table_overview.html', title='Overview', tables=[df.to_html()])

		
if __name__ == '__main__':
   app.run(debug = True)
